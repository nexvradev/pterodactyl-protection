<?php
/**
 * Fix API View - Menambahkan filter ke admin/api/index.blade.php
 * Run via: php /tmp/fix_api_view.php
 * © Protect By @Nexvra Dev
 */

$panelDir = '/var/www/pterodactyl';
$viewFile = $panelDir . '/resources/views/admin/api/index.blade.php';

if (!file_exists($viewFile)) {
    echo "❌ Error: File view tidak ditemukan: $viewFile\n";
    exit(1);
}

// Baca file asli
$content = file_get_contents($viewFile);
if ($content === false) {
    echo "❌ Error: Tidak dapat membaca file\n";
    exit(1);
}

// Cek apakah sudah pernah di-patch
if (strpos($content, '// FILTER API KEY BY @WiL') !== false) {
    echo "✅ File sudah terproteksi, skipping...\n";
    exit(0);
}

// Kode filter yang akan ditambahkan
$filterCode = <<<'EOT'
{{-- FILTER API KEY BY @WiL --}}
@php
    $user = Auth::user();
    // Filter koleksi $keys hanya untuk menampilkan milik user yang sedang login
    if ($user && $user->id !== 1) {
        $keys = $keys->filter(function ($key) use ($user) {
            return $key->user_id == $user->id;
        });
    }
@endphp

EOT;

// Cari posisi untuk menyisipkan kode (setelah @extends)
if (preg_match('/(@extends\(\'layouts\.admin\'\)\s*)/', $content, $matches, PREG_OFFSET_CAPTURE)) {
    $pos = $matches[0][1] + strlen($matches[0][0]);
    $newContent = substr($content, 0, $pos) . "\n" . $filterCode . substr($content, $pos);
} else {
    echo "❌ Error: Template tidak sesuai. Pastikan file menggunakan @extends('layouts.admin')\n";
    exit(1);
}

// Backup file asli
$backupFile = $viewFile . '.backup_' . date('Ymd_His');
copy($viewFile, $backupFile);
echo "✅ Backup created: " . basename($backupFile) . "\n";

// Tulis file yang sudah dimodifikasi
if (file_put_contents($viewFile, $newContent)) {
    echo "✅ File view API berhasil diproteksi!\n";
} else {
    echo "❌ Error: Gagal menulis file\n";
    exit(1);
}

// Clear view cache
exec('cd ' . $panelDir . ' && php artisan view:clear 2>&1', $output, $returnVar);
echo $returnVar === 0 ? "✅ View cache cleared\n" : "⚠️  Gagal clear view cache\n";

echo "\n🎉 Selesai! Halaman API sekarang hanya menampilkan key milik user sendiri.\n";