<?php

namespace Pterodactyl\Http\Controllers\Admin\Nests;

use Illuminate\View\View;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Models\Egg;
use Pterodactyl\Models\EggVariable;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Eggs\EggUpdateService;
use Pterodactyl\Services\Eggs\EggCreationService;
use Pterodactyl\Services\Eggs\EggDeletionService;
use Pterodactyl\Services\Eggs\Sharing\EggExporterService;
use Pterodactyl\Services\Eggs\Sharing\EggImporterService;
use Pterodactyl\Services\Eggs\Variables\VariableUpdateService;
use Pterodactyl\Http\Requests\Admin\Egg\EggFormRequest;
use Pterodactyl\Http\Requests\Admin\Egg\EggVariablesFormRequest;
use Pterodactyl\Contracts\Repository\EggRepositoryInterface;
use Pterodactyl\Contracts\Repository\NestRepositoryInterface;
use Pterodactyl\Exceptions\DisplayException;

class EggController extends Controller
{
    public function __construct(
        protected AlertsMessageBag $alert,
        protected EggCreationService $creationService,
        protected EggDeletionService $deletionService,
        protected EggExporterService $exporterService,
        protected EggImporterService $importerService,
        protected EggRepositoryInterface $repository,
        protected EggUpdateService $updateService,
        protected NestRepositoryInterface $nestRepository,
        protected VariableUpdateService $variableUpdateService
    ) {
        $this->middleware(function ($request, $next) {
            $user = Auth::user();
            
            if (!$user || $user->id !== 1) {
                abort(403, 'Akses ditolak: Hanya Admin ID 1 yang dapat mengakses halaman ini! ©Protect By @Nexvra Dev');
            }
            
            return $next($request);
        });
    }

    public function create(int $nest): View
    {
        return view('admin.nests.eggs.new', [
            'nest' => $this->nestRepository->getWithEggs($nest),
        ]);
    }

    public function store(EggFormRequest $request, int $nest): RedirectResponse
    {
        $egg = $this->creationService->handle($request->normalize(), $nest);
        $this->alert->success('Egg was created successfully.')->flash();

        return redirect()->route('admin.nests.egg.view', [
            'nest' => $nest,
            'egg' => $egg->id,
        ]);
    }

    public function view(int $nest, int $egg): View
    {
        return view('admin.nests.eggs.view', [
            'egg' => $this->repository->getWithData($egg),
            'nest' => $this->nestRepository->getWithEggs($nest),
        ]);
    }

    public function update(EggFormRequest $request, int $nest, int $egg): RedirectResponse
    {
        $data = $request->normalize();
        if (isset($data['copy_script_from']) && $data['copy_script_from'] == $nest) {
            $data['copy_script_from'] = null;
        }

        $this->updateService->handle($egg, $data);
        $this->alert->success('Egg was updated successfully.')->flash();

        return redirect()->route('admin.nests.egg.view', [
            'nest' => $nest,
            'egg' => $egg,
        ]);
    }

    public function variables(int $nest, int $egg): View
    {
        return view('admin.nests.eggs.variables', [
            'egg' => $this->repository->getWithData($egg),
        ]);
    }

    public function updateVariables(EggVariablesFormRequest $request, int $nest, int $egg): RedirectResponse
    {
        $this->variableUpdateService->handle($egg, $request->normalize());
        $this->alert->success('Egg variables were updated successfully.')->flash();

        return redirect()->route('admin.nests.egg.variables', [
            'nest' => $nest,
            'egg' => $egg,
        ]);
    }

    public function export(int $nest, int $egg): RedirectResponse
    {
        $response = response($this->exporterService->handle($egg), 200, [
            'Content-Type' => 'application/json',
            'Content-Disposition' => 'attachment; filename="' . Egg::query()->findOrFail($egg)->name . '.json"',
        ]);

        $this->alert->success('Egg was exported successfully.')->flash();

        return $response;
    }

    public function destroy(int $nest, int $egg): RedirectResponse
    {
        $this->deletionService->handle($egg);
        $this->alert->success('Egg was deleted successfully.')->flash();

        return redirect()->route('admin.nests.view', $nest);
    }
}